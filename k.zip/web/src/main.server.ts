import { bootstrapApplication, BootstrapContext } from '@angular/platform-browser';
import { config } from './app/app.config.server';
import { Root } from './app/root';

const bootstrap = (context: BootstrapContext) => bootstrapApplication(Root, config, context);
export default bootstrap;
