import { Component, DestroyRef, afterNextRender, inject, signal } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ProductCard } from '../core/product.model';
import { cld, srcset } from '../core/cloudinary';
import { ProductsService } from '../core/products.service';
import { EmptyCatalogue } from '../shared/empty-catalogue';
import { SpatialGrid } from '../shared/spatial-grid';
import { Reveal, Tilt } from '../shared/motion-directives';
import { ShareButton } from '../shared/share-button';

@Component({
  selector: 'qz-home',
  imports: [RouterLink, SpatialGrid, EmptyCatalogue, Reveal, Tilt, ShareButton],
  template: `
    <section class="container-qz grid md:grid-cols-[1.15fr_1fr] gap-10 items-center py-10 md:py-20">
      <div>
        <h1 class="rise text-[clamp(2.6rem,8vw,5.4rem)]">Prints for your wall. Cases for your phone.</h1>
        <p class="rise mt-6 text-lg max-w-[34rem]" style="--d: 140ms">QazvuCart sells printed wall posters and custom mobile phone cases. Pick a product, add your details, and send your order request on WhatsApp.</p>
        <div class="rise mt-8 flex flex-wrap gap-3" style="--d: 260ms">
          <a routerLink="/products" class="btn btn-primary">Browse products</a>
          <a href="#customise" class="btn btn-quiet">How customising works</a>
        </div>
      </div>
      <div class="frame-stack" [attr.aria-hidden]="hero().length ? null : 'true'">
        @for (i of [0, 1, 2]; track i) {
          @if (hero()[i]; as p) {
            @if (p.image; as img) {
              <a class="f" [routerLink]="['/products', p.slug]" [attr.data-pos]="pos(i)" [attr.aria-label]="p.name">
                <img [src]="cld(img.url, 640)" [attr.srcset]="srcset(img.url, [320, 640, 960])" sizes="(min-width: 768px) 14rem, 55vw"
                     [alt]="img.alt" [attr.width]="img.width" [attr.height]="img.height" decoding="async">
              </a>
            }
          } @else { <span class="f" [attr.data-pos]="pos(i)"></span> }
        }
        <i class="dot"></i>
      </div>
    </section>

    <section class="bg-sage py-12 md:py-20 overflow-x-clip" aria-labelledby="collections">
      <div class="container-qz">
        <h2 id="collections" qzReveal class="text-3xl md:text-5xl">Two collections</h2>
        <div class="mt-8 grid md:grid-cols-[1.3fr_1fr] gap-6 md:gap-8">
          <div qzReveal="left">
            <a routerLink="/products" qzTilt="4" class="tilt glare group block rounded-3xl bg-porcelain shadow-lift p-8 md:p-10 min-h-56 no-underline text-forest">
              <h3 class="text-2xl md:text-3xl">Wall posters</h3>
              <p class="mt-3 max-w-sm">Printed posters for your walls.</p>
              <svg class="mt-8 transition-transform duration-500 group-hover:translate-x-2" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h15M13 6l6 6-6 6"/></svg>
            </a>
          </div>
          <div qzReveal="right" [qzRevealDelay]="140" class="md:mt-10">
            <a routerLink="/products" qzTilt="4" class="tilt glare group block rounded-3xl bg-sage-soft shadow-lift p-8 md:p-10 min-h-56 no-underline text-forest">
              <h3 class="text-2xl md:text-3xl">Phone cases</h3>
              <p class="mt-3 max-w-sm">Custom cases for your phone model.</p>
              <svg class="mt-8 transition-transform duration-500 group-hover:translate-x-2" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12h15M13 6l6 6-6 6"/></svg>
            </a>
          </div>
        </div>
      </div>
    </section>

    <section class="container-qz py-12 md:py-20" aria-labelledby="featured">
      <div class="flex items-end justify-between gap-4">
        <h2 id="featured" qzReveal class="text-3xl md:text-5xl">Featured</h2>
        @if (featured().length) { <a routerLink="/products" class="btn btn-quiet btn-sm shrink-0">See all</a> }
      </div>
      <div class="mt-6">
        @if (loading()) { <p>Loading products…</p> }
        @else if (featured().length) { <qz-spatial-grid [products]="featured()" /> }
        @else { <qz-empty-catalogue [failed]="failed()" /> }
      </div>
      @if (featured().length) {
        <div qzReveal class="mt-8 flex flex-wrap items-center gap-3">
          <a routerLink="/products" class="btn btn-primary">Keep browsing</a>
          <qz-share path="/" title="QazvuCart" label="Share the store" />
        </div>
      }
    </section>

    <section id="customise" class="bg-sage-soft py-12 md:py-20" aria-labelledby="custom-h">
      <div class="container-qz grid md:grid-cols-2 gap-10">
        <h2 id="custom-h" qzReveal class="text-3xl md:text-5xl">Make it yours</h2>
        <div class="space-y-4 text-lg">
          <p qzReveal [qzRevealDelay]="100">Some products can be customised. When a product allows it, you will see fields for your details on its page, and an option to attach your image.</p>
          <p qzReveal [qzRevealDelay]="220">Your order request opens in WhatsApp. We confirm availability, delivery charges and payment instructions with you there.</p>
        </div>
      </div>
    </section>
  `,
})
export class Home {
  private api = inject(ProductsService);
  featured = signal<ProductCard[]>([]);
  hero = signal<ProductCard[]>([]);   // up to 3 newest products that have a photo, shown in the hero frames
  shift = signal(0);                  // every ~7 s the three frames swap places in 3D
  cld = cld;
  srcset = srcset;
  loading = signal(true);
  failed = signal(false);

  constructor() {
    const destroyRef = inject(DestroyRef);
    afterNextRender(() => {
      if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
      const t = setInterval(() => { if (!document.hidden) this.shift.update((n) => n + 1); }, 7000);
      destroyRef.onDestroy(() => clearInterval(t));
    });
    this.api.list().subscribe({ next: (items) => this.hero.set(items.filter((i) => i.image).slice(0, 3)), error: () => undefined });
    this.api.list({ featured: true }).subscribe({
      next: (items) => { this.featured.set(items); this.loading.set(false); },
      error: () => { this.failed.set(true); this.loading.set(false); },
    });
  }

  pos(i: number) { return (i + this.shift()) % 3; }
}
